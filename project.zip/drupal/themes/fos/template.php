<?php

/**
 * hook to replace the bartik page page.tpl.php with page--fos.tpl.php
 * @param unknown $variables
 */
function fos_preprocess_page(&$variables) {
	
	$variables['theme_hook_suggestion'] = 'page__fos';
	
}