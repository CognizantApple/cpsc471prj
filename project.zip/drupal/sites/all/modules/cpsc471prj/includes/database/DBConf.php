<?php
class DBConf {
	public static $rentalAccount = 'rental_account';
	public static $renter = 'renter';
	public static $rental = 'rental';
	public static $rentalRenters = 'rental_renters';
	public static $rentersCar = 'renters_car';
	public static $rented = 'rented';
	public static $season = 'season';
	public static $boatRentalItem = 'boat_rental_item';
	public static $rentableItem = 'rentable_item';
	public static $cottagePriceGuide = 'cottage_price_guide';
	public static $cottage = 'cottage';
	public static $boatRentalItemRate = 'boat_rental_item_rate';
	public static $pricedFor = 'priced_for';
	public static $cottageNightlyCost = 'cottage_nightly_cost';
	public static $cottageExtraAdultCost = 'cottage_extra_adult_cost';
}